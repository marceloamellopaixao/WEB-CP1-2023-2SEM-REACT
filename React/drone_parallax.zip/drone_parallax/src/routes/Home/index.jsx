import Melhores_Drones from '../../components/Melhores_Drones'
import Nossas_Lojas from '../../components/Nossas_Lojas'


export default function Home() {
    return (
        <>
            <Melhores_Drones />
            <Nossas_Lojas />
        </>
    )
}