import './style.css'

export default function Footer() {
    return (
        <footer className="footer-site">
            <div className="container">
                <p className="text-center lead">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat, illum.
                </p>
            </div>
        </footer>
    )
}